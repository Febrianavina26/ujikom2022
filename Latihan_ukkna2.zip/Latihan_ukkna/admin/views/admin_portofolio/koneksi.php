<?php 
$koneksi = mysqli_connect("localhost", "root", "", "portofolio_vina");
// if($koneksi) echo "<h1>KONEK";